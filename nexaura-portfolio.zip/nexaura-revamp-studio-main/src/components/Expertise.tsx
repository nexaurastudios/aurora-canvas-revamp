import { useState } from 'react';
import { Video, Palette, Camera, Edit, Music, Zap, ChevronDown, ChevronUp } from 'lucide-react';

const Expertise = () => {
  const [activeCard, setActiveCard] = useState<number | null>(null);

  const expertiseItems = [
    {
      icon: <Video className="w-8 h-8 text-primary" />,
      title: "Video Editing",
      shortDesc: "Professional video editing services",
      fullDesc: "Transform raw footage into compelling stories with our expert video editing. We handle everything from basic cuts to complex transitions, color grading, and audio synchronization."
    },
    {
      icon: <Palette className="w-8 h-8 text-primary" />,
      title: "Motion Graphics",
      shortDesc: "Eye-catching animated graphics",
      fullDesc: "Bring your ideas to life with stunning motion graphics. From logo animations to complex visual effects, we create engaging animations that captivate your audience."
    },
    {
      icon: <Camera className="w-8 h-8 text-primary" />,
      title: "Thumbnail Design",
      shortDesc: "Click-worthy thumbnail designs",
      fullDesc: "Increase your click-through rates with professionally designed thumbnails. We create eye-catching, brand-consistent thumbnails that stand out in any feed."
    },
    {
      icon: <Edit className="w-8 h-8 text-primary" />,
      title: "Color Grading",
      shortDesc: "Professional color correction",
      fullDesc: "Enhance the mood and visual appeal of your videos with professional color grading. We ensure consistent, cinematic looks that match your brand aesthetic."
    },
    {
      icon: <Music className="w-8 h-8 text-primary" />,
      title: "Audio Design",
      shortDesc: "Crystal clear audio production",
      fullDesc: "Perfect your audio with professional sound design, mixing, and mastering. We eliminate noise, balance levels, and add effects for crystal-clear audio quality."
    },
    {
      icon: <Zap className="w-8 h-8 text-primary" />,
      title: "Visual Effects",
      shortDesc: "Stunning VFX and compositing",
      fullDesc: "Add magic to your videos with professional visual effects. From simple compositing to complex VFX sequences, we make the impossible look effortless."
    }
  ];

  const toggleCard = (index: number) => {
    setActiveCard(activeCard === index ? null : index);
  };

  return (
    <section id="expertise" className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Our Expertise
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We specialize in comprehensive video production services that transform your vision into reality.
            Each service is crafted with precision and creativity.
          </p>
        </div>

        {/* Expertise Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {expertiseItems.map((item, index) => (
            <div
              key={index}
              className="expertise-card"
              onClick={() => toggleCard(index)}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.shortDesc}</p>
                  </div>
                </div>
                <div className="text-primary">
                  {activeCard === index ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                </div>
              </div>

              {/* Expandable Content */}
              <div className={`overflow-hidden transition-all duration-300 ${
                activeCard === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
              }`}>
                <div className="pt-4 border-t border-border">
                  <p className="text-muted-foreground leading-relaxed">{item.fullDesc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Expertise;