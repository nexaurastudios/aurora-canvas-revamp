import { useState } from 'react';
import { Play, ExternalLink } from 'lucide-react';

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('thumbnails');

  const categories = [
    { id: 'thumbnails', name: 'Thumbnail Designing' },
    { id: 'long', name: 'Long Videos' },
    { id: 'short', name: 'Short Videos' }
  ];

  // Mock portfolio items - In real app, these would come from your data
  const thumbnailItems = [
    {
      id: 1,
      title: "Gaming Thumbnail Design",
      image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=225&fit=crop",
      category: "Gaming"
    },
    {
      id: 2,
      title: "Tech Review Thumbnail",
      image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=225&fit=crop",
      category: "Technology"
    },
    {
      id: 3,
      title: "Lifestyle Vlog Thumbnail",
      image: "https://images.unsplash.com/photo-1494790108755-2616c35d0b49?w=400&h=225&fit=crop",
      category: "Lifestyle"
    },
    {
      id: 4,
      title: "Business Tutorial Thumbnail",
      image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&h=225&fit=crop",
      category: "Business"
    },
    {
      id: 5,
      title: "Travel Vlog Thumbnail",
      image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=400&h=225&fit=crop",
      category: "Travel"
    },
    {
      id: 6,
      title: "Fitness Channel Thumbnail",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=225&fit=crop",
      category: "Fitness"
    }
  ];

  const videoItems = [
    {
      id: 1,
      title: "Brand Commercial",
      image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=225&fit=crop",
      duration: "2:30",
      category: "Commercial"
    },
    {
      id: 2,
      title: "Product Showcase",
      image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400&h=225&fit=crop",
      duration: "1:45",
      category: "Product"
    },
    {
      id: 3,
      title: "Corporate Video",
      image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=225&fit=crop",
      duration: "3:15",
      category: "Corporate"
    },
    {
      id: 4,
      title: "Event Highlight Reel",
      image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&h=225&fit=crop",
      duration: "4:20",
      category: "Event"
    }
  ];

  const shortVideoItems = [
    {
      id: 1,
      title: "Instagram Reel",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=533&fit=crop",
      duration: "0:30",
      category: "Social Media"
    },
    {
      id: 2,
      title: "TikTok Content",
      image: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=300&h=533&fit=crop",
      duration: "0:15",
      category: "TikTok"
    },
    {
      id: 3,
      title: "YouTube Shorts",
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=300&h=533&fit=crop",
      duration: "0:45",
      category: "YouTube"
    },
    {
      id: 4,
      title: "Promo Short",
      image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=300&h=533&fit=crop",
      duration: "0:20",
      category: "Promotion"
    }
  ];

  const getPortfolioItems = () => {
    switch (activeCategory) {
      case 'thumbnails':
        return thumbnailItems;
      case 'long':
        return videoItems;
      case 'short':
        return shortVideoItems;
      default:
        return thumbnailItems;
    }
  };

  const getGridCols = () => {
    if (activeCategory === 'short') {
      return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
    }
    return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
  };

  return (
    <section id="portfolio" className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Our Portfolio
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our latest work across different categories. Each project showcases our commitment 
            to quality and creative excellence.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center mb-12">
          <div className="glass rounded-2xl p-2 inline-flex gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-glow'
                    : 'text-muted-foreground hover:text-foreground hover:bg-white/10'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className={`grid ${getGridCols()} gap-6 max-w-7xl mx-auto`}>
          {getPortfolioItems().map((item, index) => (
            <div
              key={`${activeCategory}-${item.id}`}
              className={`portfolio-card group fade-in stagger-delay-${(index % 4) + 1} ${
                activeCategory === 'short' ? 'aspect-[9/16]' : 'aspect-video'
              }`}
            >
              <div className="relative h-full">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="text-center">
                    {activeCategory !== 'thumbnails' && (
                      <div className="flex items-center justify-center mb-4">
                        <button className="bg-primary/20 backdrop-blur-sm border border-primary/30 rounded-full p-4 hover:bg-primary/30 transition-colors">
                          <Play className="w-6 h-6 text-primary fill-current" />
                        </button>
                      </div>
                    )}
                    <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                    <div className="flex items-center justify-center gap-4 text-sm text-white/80">
                      <span>{item.category}</span>
                       {activeCategory !== 'thumbnails' && 'duration' in item && (
                        <>
                          <span>•</span>
                          <span>{(item as any).duration}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* View Link */}
                <button className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-black/70">
                  <ExternalLink className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">
            Ready to bring your vision to life?
          </p>
          <button className="btn-hero">
            Start Your Project
          </button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;