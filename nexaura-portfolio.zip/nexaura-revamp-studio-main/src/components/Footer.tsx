import { Mail, Phone, MapPin, Instagram, Twitter, Youtube, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="relative py-20 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-4">
              NexAura Studios
            </div>
            <p className="text-muted-foreground mb-6 max-w-md">
              Professional video production studio specializing in video editing, motion graphics, 
              and thumbnail design that transforms your vision into captivating content.
            </p>
            
            {/* Social Links */}
            <div className="flex gap-4">
              {[
                { icon: <Instagram size={20} />, href: '#', label: 'Instagram' },
                { icon: <Youtube size={20} />, href: '#', label: 'YouTube' },
                { icon: <Twitter size={20} />, href: '#', label: 'Twitter' },
                { icon: <Linkedin size={20} />, href: '#', label: 'LinkedIn' }
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="p-3 glass rounded-xl hover:bg-primary/20 hover:text-primary transition-colors"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-3">
              {[
                'Video Editing',
                'Motion Graphics', 
                'Thumbnail Design',
                'Color Grading',
                'Audio Design',
                'Visual Effects'
              ].map((service, index) => (
                <li key={index}>
                  <a href="#expertise" className="text-muted-foreground hover:text-foreground transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Mail size={18} className="text-primary" />
                <span>hello@nexaurastudios.com</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Phone size={18} className="text-primary" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin size={18} className="text-primary" />
                <span>Los Angeles, CA</span>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter */}
        <div className="glass rounded-2xl p-8 mb-12 text-center">
          <h3 className="text-2xl font-bold mb-4">Stay Updated</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest video production tips, industry insights, 
            and exclusive behind-the-scenes content.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 bg-background/50 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
            <button className="btn-hero px-8 py-3">
              Subscribe
            </button>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-border text-center text-muted-foreground">
          <p>&copy; 2024 NexAura Studios. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;